# SaveMod++ by Grok  v5.0.0-ultra

Мощный Telegram Business-бот (Автоматизация чатов) с огромным количеством функций.

Токен и Admin ID уже прописаны.

## Запуск

```bash
pip install -r requirements.txt
python bot.py
```

После запуска:
1. @BotFather → Bot Settings → Business Mode → Turn on
2. Telegram → Настройки → Telegram для бизнеса / Автоматизация чатов → добавь бота

## Основные возможности (SaveMod-ядро)

- Ловит **удалённые** сообщения и присылает копию
- Ловит **правки** (было → стало)
- Сохраняет **view-once / protected** медиа (ответь на сообщение)
- Полная статистика, поиск, экспорт
- Настройки (свои сообщения, медиа, уведомления)
- SQLite, авто-очистка, лимиты

## Команды с префиксом `.`

### Работа с сообщениями
`.help` `.stats` `.settings` `.profile` `.я` `.id`  
`.search текст` `.export` `.last` `.clear` `.media`

### Форматирование и текст
`.sw` (раскладка) `.bold` `.italic` `.monospace` `.underline`  
`.leet` `.kawaii` `.love` `.type` `.reverse` `.upper` `.lower` `.count`

### Весёлые / тролль
`.troll` `.spam` `.zaebu` `.mute` `.check`  
`.random` `.choose` `.coin` `.dice` `.ball` `.8ball`  
`.joke` `.quote` `.fact` `.say` `.repeat`

### Социальные
`.ship` `.rate` `.howgay` `.pp`  
`.hug` `.kiss` `.pat` `.slap` `.kill`  
`.table` `.untable` `.shrug` `.lenny` `.magic` `.fight`

### Утилиты
`.password` `.uuid` `.calc` `.whoami` `.server` `.uptime`  
`.weather` (заглушка)

### Админ (только владелец)
`.admin` `.users` `.clean` `.broadcast`

## Структура

```
bot.py              — точка входа
config.py           — токен + настройки
db/database.py      — SQLite
handlers/
  commands.py       — основные команды + меню
  business.py       — удаления / правки / media
  fun.py            — все .команды (очень много)
media/              — сохранённые файлы
```

Сделано с Grok (xAI)
